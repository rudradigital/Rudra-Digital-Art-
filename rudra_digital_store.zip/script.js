function showAlert() {
    alert('रुद्र डिजिटल स्टोर में आपका स्वागत है!');
}
